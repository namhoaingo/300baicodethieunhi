package pluralsight.oop.aircraft;

public enum WakeTurbulence {

}
