package pluralsight.oop;

import pluralsight.oop.aircraft.Aircraft;
import pluralsight.oop.aircraft.TakeOffDistancingRules;
import pluralsight.oop.aircraft.WakeTurbulence;
import java.time.LocalDateTime;
import java.util.List;

public class Main {
    public static void main(String[] args) {

    }
}
