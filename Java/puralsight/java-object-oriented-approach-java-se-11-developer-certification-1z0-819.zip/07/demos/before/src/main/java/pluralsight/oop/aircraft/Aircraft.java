package pluralsight.oop.aircraft;

public class Aircraft {

}