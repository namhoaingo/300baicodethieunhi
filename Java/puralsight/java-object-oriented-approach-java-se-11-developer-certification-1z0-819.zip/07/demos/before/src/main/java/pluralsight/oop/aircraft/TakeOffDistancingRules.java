package pluralsight.oop.aircraft;

import java.util.Map;

public class TakeOffDistancingRules {

}
