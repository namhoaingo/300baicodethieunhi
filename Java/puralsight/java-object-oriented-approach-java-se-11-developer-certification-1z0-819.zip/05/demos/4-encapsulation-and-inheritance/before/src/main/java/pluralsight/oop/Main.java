package pluralsight.oop;

import pluralsight.oop.geography.LatLon;
import pluralsight.oop.geography.Route;
import pluralsight.oop.geography.Shape;
import pluralsight.oop.geography.Waypoint;

import java.util.List;

public class Main {
    public static void main(String[] args) {
    }
}
