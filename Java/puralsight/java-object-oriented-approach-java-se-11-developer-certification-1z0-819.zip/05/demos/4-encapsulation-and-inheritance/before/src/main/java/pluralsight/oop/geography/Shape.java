package pluralsight.oop.geography;

public abstract class Shape {

}
