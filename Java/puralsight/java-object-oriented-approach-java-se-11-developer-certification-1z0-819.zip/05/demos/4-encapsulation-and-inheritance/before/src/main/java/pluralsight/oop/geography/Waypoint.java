package pluralsight.oop.geography;

public final class Waypoint extends Shape {

}
