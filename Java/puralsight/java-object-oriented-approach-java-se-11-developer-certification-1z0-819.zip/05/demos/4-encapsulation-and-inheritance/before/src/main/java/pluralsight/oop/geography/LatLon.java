package pluralsight.oop.geography;

public class LatLon {

}
