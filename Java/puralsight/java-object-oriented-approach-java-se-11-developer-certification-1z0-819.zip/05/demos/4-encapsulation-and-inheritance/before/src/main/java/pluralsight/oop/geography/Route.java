package pluralsight.oop.geography;

import java.util.List;

public final class Route extends Shape {

}
