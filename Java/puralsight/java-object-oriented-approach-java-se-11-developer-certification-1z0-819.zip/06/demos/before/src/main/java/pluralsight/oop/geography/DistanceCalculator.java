package pluralsight.oop.geography;

public interface DistanceCalculator {

}
