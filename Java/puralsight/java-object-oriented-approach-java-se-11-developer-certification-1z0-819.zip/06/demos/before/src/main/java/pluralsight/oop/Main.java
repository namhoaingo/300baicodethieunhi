package pluralsight.oop;

import pluralsight.oop.airspace.AirSector;
import pluralsight.oop.airspace.EnRouteSector;
import pluralsight.oop.airspace.TMASector;
import pluralsight.oop.geography.Circle;
import pluralsight.oop.geography.Coordinate;
import pluralsight.oop.geography.Rectangle;
import pluralsight.oop.radar.Aircraft;

import java.util.List;

public class Main {
    public static void main(String[] args) {

    }
}
