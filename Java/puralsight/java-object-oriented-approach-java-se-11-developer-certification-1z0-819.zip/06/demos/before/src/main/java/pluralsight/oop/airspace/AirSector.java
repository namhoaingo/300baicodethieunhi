package pluralsight.oop.airspace;

import pluralsight.oop.geography.Coordinate;

public interface AirSector {

}
