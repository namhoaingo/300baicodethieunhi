package pluralsight.oop;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        /*
        Create a radar target
        Print the label
        Send a change altitude command
        Watch the behaviour
         */
    }
}
