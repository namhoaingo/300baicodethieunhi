package org.agoncal.application.cdbookstore.util;

/**
 * @author Antonio Goncalves
 *         http://www.antoniogoncalves.org
 *         --
 */

public interface NumberGenerator {

    // ======================================
    // =          Business methods          =
    // ======================================

    String generateNumber();
}