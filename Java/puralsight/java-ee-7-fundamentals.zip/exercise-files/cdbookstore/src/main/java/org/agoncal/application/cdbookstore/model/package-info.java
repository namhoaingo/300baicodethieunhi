@Vetoed
package org.agoncal.application.cdbookstore.model;

import javax.enterprise.inject.Vetoed;