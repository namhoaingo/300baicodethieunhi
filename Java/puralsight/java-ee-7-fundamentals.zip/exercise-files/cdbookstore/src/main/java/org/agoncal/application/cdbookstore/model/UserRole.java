package org.agoncal.application.cdbookstore.model;

/**
 * @author Antonio Goncalves
 *         http://www.antoniogoncalves.org
 *         --
 */

public enum UserRole {

    // ======================================
    // =             Constants              =
    // ======================================

    USER, ADMIN
}